#!/usr/bin/env python3
# Script that scans web server logs for 404 errors
# By 