#!/usr/bin/env python3
# Sample script that reads from a file
# By 