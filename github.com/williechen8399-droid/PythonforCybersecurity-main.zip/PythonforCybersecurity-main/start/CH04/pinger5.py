#!/usr/bin/env python3
# Fifth example of pinging from Python
# Reading IPs from a file
# By 