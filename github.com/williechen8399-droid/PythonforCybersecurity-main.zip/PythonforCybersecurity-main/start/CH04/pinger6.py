#!/usr/bin/env python3
# Sixth example of pinging from Python
# Writing log messages to a file
# By 