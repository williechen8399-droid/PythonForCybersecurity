#!/usr/bin/env python3
# Sample script that writes to a file
# By 