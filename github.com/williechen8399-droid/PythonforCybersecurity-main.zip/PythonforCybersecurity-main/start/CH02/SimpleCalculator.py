#!/usr/bin/env python3
# A simple calculator to show math and conditionals
# Created 
