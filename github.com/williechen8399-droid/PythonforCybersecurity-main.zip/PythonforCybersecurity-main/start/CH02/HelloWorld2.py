#!/usr/bin/env python3
# A simple "Hello World" script in python with Inputs
# Created 

# Suggestion, build out 1 line at a time
# Once multiple print statemetns exist, put a breakpoint at first print line
# Then walk through as an example of "debugging"
