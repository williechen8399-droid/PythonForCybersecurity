#!/usr/bin/env python3
# Script that "encrypts"/"decrypts" text using base64 encoding
# By 