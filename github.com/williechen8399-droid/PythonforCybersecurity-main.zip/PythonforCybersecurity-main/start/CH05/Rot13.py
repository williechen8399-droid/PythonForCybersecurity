#!/usr/bin/env python3
# Script that encrypts/decrypts text using ROT13
# By 