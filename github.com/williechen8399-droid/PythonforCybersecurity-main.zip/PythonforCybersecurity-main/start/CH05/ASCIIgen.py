#!/usr/bin/env python3
# ASCII generator
# Uses chr() to create ASCII characters
# By 