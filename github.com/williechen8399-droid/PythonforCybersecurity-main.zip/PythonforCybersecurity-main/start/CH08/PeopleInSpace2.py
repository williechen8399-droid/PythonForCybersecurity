#!/usr/bin/env python3
# Script that tells us how many people there are in space
#By 