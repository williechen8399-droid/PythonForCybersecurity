#!/usr/bin/env python3
# Script that connects to HuggingFace and performs a query
# Requires an API key to run - https://huggingface.co/settings/tokens
# By 

# Import Python modules


# Ask the user for a prompt

# Get API key

# Generate the image from text

# Save image to file
