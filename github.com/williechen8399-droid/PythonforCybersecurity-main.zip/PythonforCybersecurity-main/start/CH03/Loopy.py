#!/usr/bin/env python3
# example workign with Loops
#By 