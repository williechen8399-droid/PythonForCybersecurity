#!/usr/bin/env python3
# Second example of pinging from Python
# By 