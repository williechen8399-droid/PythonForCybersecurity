#!/usr/bin/env python3
# Fourth example of pinging from Python
# By 