#!/usr/bin/env python3
# First example of pinging from Python
# By 