# Various tkinter geometry managers
# View how pack, grid, place work together
# Created by Ed 11/15

# Import tkinter

# Create the GUI main window

# Using pack in a separate frame

# Using grid in another frame

# Using place in the root window


# Enter the main event loop
