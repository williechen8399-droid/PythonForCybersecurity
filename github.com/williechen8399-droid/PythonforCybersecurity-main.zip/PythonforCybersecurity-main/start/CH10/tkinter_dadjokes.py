# third tkinter script
# Get people in space
# Create by 

# Import tkinter

# Functions

# Create the GUI main window

# Create font object
# Set wraplength to 25 characters

# Add widgets

# Enter the main event loop