# Seconder tkinter script
# Add a button and command
# Create 

# Import tkinter

# Functions

# Create the GUI main window

# Add widgets

# Enter the main event loop