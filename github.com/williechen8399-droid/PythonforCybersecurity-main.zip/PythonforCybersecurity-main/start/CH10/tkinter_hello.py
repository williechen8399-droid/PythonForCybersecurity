# First tkinter script
# Create by 

# Import tkinter

# Create the GUI main window

# Add widgets

# Enter the main event loop