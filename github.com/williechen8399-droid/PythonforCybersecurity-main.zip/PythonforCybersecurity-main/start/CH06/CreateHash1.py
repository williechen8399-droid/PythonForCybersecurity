#!/usr/bin/env python3
# Script that hashes a password
# By 