#!/usr/bin/env python3
# Script that hashes a password with provided salt
# By 