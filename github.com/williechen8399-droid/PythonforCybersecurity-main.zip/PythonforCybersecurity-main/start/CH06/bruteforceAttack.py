#!/usr/bin/env python3
# Example brute-force attacker
#By Ed Goad
# date: 2/5/2021

# NOTE: this example is limited to numbers. There are no letters or symbols in this example
# Suggested to start by debugging to show how brute force walks through all available options 


hashed_password = "$6$G.DTW7g9s5U7KYf5$QFcHx0/J88HV/Q0ab653gfYQ1KyNGx5HRhDQYyai2ZUy7Aw4tyfJ6/kI6kllfXl0DyS.LuaUJvqnlIn2fVM5F0"
algorithm_salt = "$6$G.DTW7g9s5U7KYf5$"
