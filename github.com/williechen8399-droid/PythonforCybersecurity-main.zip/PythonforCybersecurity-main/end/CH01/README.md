# Intro to Linux environment
Brief introduction to Raspberry Pi
- Why it was invented
- benefits of Linux
- some simple commands + links to finding more

# Workign with github
Create GitHub Account
Use `git clone` to download/sync to linux
Commands to push/pull
```
git pull
git add .
git commit -m "comment here"
git push
```
github publish script

## Optionally
- using .gitignore
- other ways to store passwords

# Intro to python - no scripting, just talk about it
Benefits of python
Where python is used
Interpreted vs compiled language
