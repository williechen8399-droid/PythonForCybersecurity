# Reading Files
create a file named **testfile.txt** and show how to read it
readFile.py

Create a new file **ips.txt** and use it as input for loop (put whatever IPs desired)
pinger4.py

If time exists, put bad data in ips.txt and show how important it is to validate input

# Writing Files
show how to write a file
writeFile.py

Create function to write to a log
pinger5.py
Extend log by adding date/time
- google how to get date/time for python