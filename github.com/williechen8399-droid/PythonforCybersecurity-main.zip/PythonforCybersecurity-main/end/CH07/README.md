geolocation api: https://ipstack.com/

Im not happy with the geolocate
I think it would be better to further analyze the apache logs for hacking

possibly include regex examples for CC#, SSN# or other interesting info


access.log pulled from http://www.almhuette-raith.at/apache-log/access.log on 3/23/2021
    need to sanitize