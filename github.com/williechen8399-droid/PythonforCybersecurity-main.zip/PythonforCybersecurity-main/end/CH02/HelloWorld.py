#!/usr/bin/env python3
# A simple "Hello World" script in python
# Created by Ed Goad, 2/3
print("Hello World")