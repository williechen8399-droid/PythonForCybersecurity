# Starting with python3
- interactive python
```
python3
20 + 32
15 - 7
7 * 7
2 ** 8
print("Hello There")
```
- variables: variable is a box, whats in it what you put there
```
message = "Hello There"
print(message)
n = 17
pi = 3.1415926535
print(n + pi)
```
- data types
```
type(message)
type(n)
type(pi)
```
# Starting with an IDE
- Installing VSCode
- Syncronizing with GitHub


# creating first few scripts
### HelloWorld.py
- Commit to Github
- Running in IDE and command line

### HelloWorld2.py
- Commit and run with simple input/print
- Different ways to print the hello statement (add all then run)

# Use IDE debugger
- Using HelloWorld2.py
- stop at first print statement and step through code