#!/usr/bin/env python3
# A simple "Hello World" script in python with Inputs
# Created by Ed Goad, 2/3

your_name = input("What is your name? ")
print("Hello {0}".format(your_name))
